package modeloER.modeloER.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String ModeloERCreationWizardTitle;

	/**
	* @generated
	*/
	public static String ModeloERCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String ModeloERCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String ModeloERCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String ModeloERCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String ModeloERCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String ModeloERCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String ModeloERCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String ModeloERDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String ModeloERDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String ModeloERDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String ModeloERDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String ModeloERDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String ModeloERDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String ModeloERDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String ModeloERDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String ModeloERDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String ModeloERDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String ModeloERDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String ModeloERDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String ModeloERDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String ModeloERNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String ModeloERDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String ModeloERDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String ModeloERDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String ModeloERDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String ModeloERDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String ModeloERElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String Atributos1Group_title;

	/**
	* @generated
	*/
	public static String Nodos2Group_title;

	/**
	* @generated
	*/
	public static String Relaciones3Group_title;

	/**
	* @generated
	*/
	public static String AtributoDerivado1CreationTool_title;

	/**
	* @generated
	*/
	public static String AtributoDerivado1CreationTool_desc;

	/**
	* @generated
	*/
	public static String AtributoMultivaluado2CreationTool_title;

	/**
	* @generated
	*/
	public static String AtributoMultivaluado2CreationTool_desc;

	/**
	* @generated
	*/
	public static String ClavePrimaria3CreationTool_title;

	/**
	* @generated
	*/
	public static String ClavePrimaria3CreationTool_desc;

	/**
	* @generated
	*/
	public static String Atributo4CreationTool_title;

	/**
	* @generated
	*/
	public static String Atributo4CreationTool_desc;

	/**
	* @generated
	*/
	public static String Herencia1CreationTool_title;

	/**
	* @generated
	*/
	public static String Herencia1CreationTool_desc;

	/**
	* @generated
	*/
	public static String RelacionTipoDebil2CreationTool_title;

	/**
	* @generated
	*/
	public static String RelacionTipoDebil2CreationTool_desc;

	/**
	* @generated
	*/
	public static String RelacionTipoFuerte3CreationTool_title;

	/**
	* @generated
	*/
	public static String RelacionTipoFuerte3CreationTool_desc;

	/**
	* @generated
	*/
	public static String Entidad4CreationTool_title;

	/**
	* @generated
	*/
	public static String Entidad4CreationTool_desc;

	/**
	* @generated
	*/
	public static String EntidadDebil5CreationTool_title;

	/**
	* @generated
	*/
	public static String EntidadDebil5CreationTool_desc;

	/**
	* @generated
	*/
	public static String LinkEntidadRelacion1CreationTool_title;

	/**
	* @generated
	*/
	public static String LinkEntidadRelacion1CreationTool_desc;

	/**
	* @generated
	*/
	public static String LinkEntidadRelacionDebil2CreationTool_title;

	/**
	* @generated
	*/
	public static String LinkEntidadRelacionDebil2CreationTool_desc;

	/**
	* @generated
	*/
	public static String LinkSimple3CreationTool_title;

	/**
	* @generated
	*/
	public static String LinkSimple3CreationTool_desc;

	/**
	* @generated
	*/
	public static String RelacionLineaDiscontinua4CreationTool_title;

	/**
	* @generated
	*/
	public static String RelacionLineaDiscontinua4CreationTool_desc;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Diagrama_1000_links;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoDerivado_2001_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoDerivado_2001_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_ClavePrimaria_2002_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoSimple_2003_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoCompuesto_2004_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoCompuesto_2004_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_RelacionTipoDebil_2005_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_RelacionTipoFuerte_2006_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoMultivaluado_2007_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Herencia_2008_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Herencia_2008_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EntidadFuerte_2009_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EntidadFuerte_2009_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EntidadDebil_2010_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EntidadDebil_2010_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoEntidadLink_4001_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoEntidadLink_4001_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_LinkHerenciaHijo_4002_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_LinkHerenciaHijo_4002_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EntidadRelacionFuerte_4003_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EntidadRelacionFuerte_4003_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EntidadRelacionDebil_4004_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_EntidadRelacionDebil_4004_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_LinkASAC_4005_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_LinkASAC_4005_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_RelacionAtributoLink_4006_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_RelacionAtributoLink_4006_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_LinkHerenciaPadre_4007_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_LinkHerenciaPadre_4007_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoDerivadoEntidad_4008_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoDerivadoEntidad_4008_source;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String MessageFormatParser_InvalidInputError;

	/**
	* @generated
	*/
	public static String ModeloERModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String ModeloERModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
