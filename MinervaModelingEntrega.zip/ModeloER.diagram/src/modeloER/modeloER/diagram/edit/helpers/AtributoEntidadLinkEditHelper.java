package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class AtributoEntidadLinkEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
