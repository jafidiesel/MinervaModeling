package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class RelacionTipoFuerteEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
