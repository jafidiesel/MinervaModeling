package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class AtributoCompuestoEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
