/**
 */
package modeloER.impl;

import modeloER.EntidadDebil;
import modeloER.ModeloERPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Entidad Debil</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EntidadDebilImpl extends EntidadImpl implements EntidadDebil {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EntidadDebilImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.ENTIDAD_DEBIL;
	}

} //EntidadDebilImpl
