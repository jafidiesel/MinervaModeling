/**
 */
package modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Atributo Derivado</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.ModeloERPackage#getAtributoDerivado()
 * @model
 * @generated
 */
public interface AtributoDerivado extends Atributo {
} // AtributoDerivado
