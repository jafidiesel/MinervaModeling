/**
 */
package modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Clave Primaria Foranea</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.ModeloERPackage#getClavePrimariaForanea()
 * @model
 * @generated
 */
public interface ClavePrimariaForanea extends Atributo {
} // ClavePrimariaForanea
