/**
 */
package modeloER.modeloER.impl;

import modeloER.modeloER.AtributoMultivaluado;
import modeloER.modeloER.ModeloERPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Atributo Multivaluado</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AtributoMultivaluadoImpl extends AtributoImpl implements AtributoMultivaluado {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AtributoMultivaluadoImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.ATRIBUTO_MULTIVALUADO;
	}

} //AtributoMultivaluadoImpl
