/**
 */
package modeloER.modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Atributo Simple</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.modeloER.ModeloERPackage#getAtributoSimple()
 * @model
 * @generated
 */
public interface AtributoSimple extends Atributo {
} // AtributoSimple
