/**
 */
package modeloER.modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Clave Primaria</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.modeloER.ModeloERPackage#getClavePrimaria()
 * @model
 * @generated
 */
public interface ClavePrimaria extends Atributo {
} // ClavePrimaria
