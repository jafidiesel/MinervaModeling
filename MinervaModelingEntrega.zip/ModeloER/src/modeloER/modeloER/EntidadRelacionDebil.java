/**
 */
package modeloER.modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entidad Relacion Debil</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.modeloER.ModeloERPackage#getEntidadRelacionDebil()
 * @model
 * @generated
 */
public interface EntidadRelacionDebil extends EntidadRelacion {
} // EntidadRelacionDebil
