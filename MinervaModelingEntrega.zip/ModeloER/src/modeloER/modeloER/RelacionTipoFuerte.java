/**
 */
package modeloER.modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Relacion Tipo Fuerte</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.modeloER.ModeloERPackage#getRelacionTipoFuerte()
 * @model
 * @generated
 */
public interface RelacionTipoFuerte extends Relacion {
} // RelacionTipoFuerte
