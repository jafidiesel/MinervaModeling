package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class LinkHerenciaPadreEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
