package modeloER.modeloER.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class ModeloERIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public ModeloERIconProvider() {
		super(modeloER.modeloER.diagram.providers.ModeloERElementTypes.TYPED_INSTANCE);
	}

}
