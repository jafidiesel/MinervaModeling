package modeloER.modeloER.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class ModeloEREditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public ModeloEREditPartProvider() {
		super(new modeloER.modeloER.diagram.edit.parts.ModeloEREditPartFactory(),
				modeloER.modeloER.diagram.part.ModeloERVisualIDRegistry.TYPED_INSTANCE,
				modeloER.modeloER.diagram.edit.parts.DiagramaEditPart.MODEL_ID);
	}

}
