package modeloER.modeloER.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	* @generated
	*/
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(
				modeloER.modeloER.diagram.part.ModeloERDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
