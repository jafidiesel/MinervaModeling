/**
 */
package modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tipo Fuerte</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.ModeloERPackage#getTipoFuerte()
 * @model
 * @generated
 */
public interface TipoFuerte extends Relacion {
} // TipoFuerte
