/**
 */
package modeloER.impl;

import modeloER.EntidadRelacionDebil;
import modeloER.ModeloERPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Entidad Relacion Debil</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EntidadRelacionDebilImpl extends EntidadRelacionImpl implements EntidadRelacionDebil {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EntidadRelacionDebilImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.ENTIDAD_RELACION_DEBIL;
	}

} //EntidadRelacionDebilImpl
