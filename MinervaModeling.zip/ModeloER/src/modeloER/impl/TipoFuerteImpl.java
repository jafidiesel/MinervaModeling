/**
 */
package modeloER.impl;

import modeloER.ModeloERPackage;
import modeloER.TipoFuerte;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tipo Fuerte</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TipoFuerteImpl extends RelacionImpl implements TipoFuerte {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TipoFuerteImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.TIPO_FUERTE;
	}

} //TipoFuerteImpl
