/**
 */
package modeloER.impl;

import modeloER.AtributoDerivadoClavePrimaria;
import modeloER.ModeloERPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Atributo Derivado Clave Primaria</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AtributoDerivadoClavePrimariaImpl extends AtributoImpl implements AtributoDerivadoClavePrimaria {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AtributoDerivadoClavePrimariaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.ATRIBUTO_DERIVADO_CLAVE_PRIMARIA;
	}

} //AtributoDerivadoClavePrimariaImpl
