/**
 */
package modeloER.modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entidad Debil</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.modeloER.ModeloERPackage#getEntidadDebil()
 * @model
 * @generated
 */
public interface EntidadDebil extends Entidad {
} // EntidadDebil
