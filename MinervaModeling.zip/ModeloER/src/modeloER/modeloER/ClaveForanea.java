/**
 */
package modeloER.modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Clave Foranea</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.modeloER.ModeloERPackage#getClaveForanea()
 * @model
 * @generated
 */
public interface ClaveForanea extends Atributo {
} // ClaveForanea
