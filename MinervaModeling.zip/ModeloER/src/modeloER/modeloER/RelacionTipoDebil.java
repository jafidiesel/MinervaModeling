/**
 */
package modeloER.modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Relacion Tipo Debil</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.modeloER.ModeloERPackage#getRelacionTipoDebil()
 * @model
 * @generated
 */
public interface RelacionTipoDebil extends Relacion {
} // RelacionTipoDebil
