/**
 */
package modeloER.modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Atributo Compuesto</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.modeloER.ModeloERPackage#getAtributoCompuesto()
 * @model
 * @generated
 */
public interface AtributoCompuesto extends Atributo {

} // AtributoCompuesto
