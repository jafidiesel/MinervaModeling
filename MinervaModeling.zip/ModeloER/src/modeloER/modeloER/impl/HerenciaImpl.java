/**
 */
package modeloER.modeloER.impl;

import modeloER.modeloER.Herencia;
import modeloER.modeloER.ModeloERPackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Herencia</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class HerenciaImpl extends MinimalEObjectImpl.Container implements Herencia {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HerenciaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.HERENCIA;
	}

} //HerenciaImpl
