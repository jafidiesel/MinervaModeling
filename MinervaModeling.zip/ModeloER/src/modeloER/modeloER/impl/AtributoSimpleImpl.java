/**
 */
package modeloER.modeloER.impl;

import modeloER.modeloER.AtributoSimple;
import modeloER.modeloER.ModeloERPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Atributo Simple</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AtributoSimpleImpl extends AtributoImpl implements AtributoSimple {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AtributoSimpleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.ATRIBUTO_SIMPLE;
	}

} //AtributoSimpleImpl
