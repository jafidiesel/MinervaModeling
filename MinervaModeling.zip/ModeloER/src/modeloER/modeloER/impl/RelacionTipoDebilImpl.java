/**
 */
package modeloER.modeloER.impl;

import modeloER.modeloER.ModeloERPackage;
import modeloER.modeloER.RelacionTipoDebil;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Relacion Tipo Debil</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RelacionTipoDebilImpl extends RelacionImpl implements RelacionTipoDebil {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RelacionTipoDebilImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.RELACION_TIPO_DEBIL;
	}

} //RelacionTipoDebilImpl
