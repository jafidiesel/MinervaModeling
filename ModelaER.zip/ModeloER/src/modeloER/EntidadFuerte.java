/**
 */
package modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entidad Fuerte</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.ModeloERPackage#getEntidadFuerte()
 * @model
 * @generated
 */
public interface EntidadFuerte extends Entidad {
} // EntidadFuerte
