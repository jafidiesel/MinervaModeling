/**
 */
package modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entidad Relacion Fuerte</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.ModeloERPackage#getEntidadRelacionFuerte()
 * @model
 * @generated
 */
public interface EntidadRelacionFuerte extends EntidadRelacion {
} // EntidadRelacionFuerte
