/**
 */
package modeloER.impl;

import modeloER.EntidadRelacionFuerte;
import modeloER.ModeloERPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Entidad Relacion Fuerte</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EntidadRelacionFuerteImpl extends EntidadRelacionImpl implements EntidadRelacionFuerte {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EntidadRelacionFuerteImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.ENTIDAD_RELACION_FUERTE;
	}

} //EntidadRelacionFuerteImpl
