/**
 */
package modeloER.impl;

import modeloER.ClavePrimaria;
import modeloER.ModeloERPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Clave Primaria</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ClavePrimariaImpl extends AtributoImpl implements ClavePrimaria {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClavePrimariaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.CLAVE_PRIMARIA;
	}

} //ClavePrimariaImpl
