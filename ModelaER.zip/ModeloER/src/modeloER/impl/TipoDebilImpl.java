/**
 */
package modeloER.impl;

import modeloER.ModeloERPackage;
import modeloER.TipoDebil;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tipo Debil</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TipoDebilImpl extends RelacionImpl implements TipoDebil {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TipoDebilImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.TIPO_DEBIL;
	}

} //TipoDebilImpl
