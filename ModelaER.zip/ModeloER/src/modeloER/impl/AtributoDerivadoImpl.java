/**
 */
package modeloER.impl;

import modeloER.AtributoDerivado;
import modeloER.ModeloERPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Atributo Derivado</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AtributoDerivadoImpl extends AtributoImpl implements AtributoDerivado {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AtributoDerivadoImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.ATRIBUTO_DERIVADO;
	}

} //AtributoDerivadoImpl
