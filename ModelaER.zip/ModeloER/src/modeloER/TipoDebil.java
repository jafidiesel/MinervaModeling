/**
 */
package modeloER;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tipo Debil</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeloER.ModeloERPackage#getTipoDebil()
 * @model
 * @generated
 */
public interface TipoDebil extends Relacion {
} // TipoDebil
