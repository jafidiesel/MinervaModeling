/**
 */
package modeloER.modeloER.impl;

import modeloER.modeloER.ClavePrimariaForanea;
import modeloER.modeloER.ModeloERPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Clave Primaria Foranea</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ClavePrimariaForaneaImpl extends AtributoImpl implements ClavePrimariaForanea {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClavePrimariaForaneaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.CLAVE_PRIMARIA_FORANEA;
	}

} //ClavePrimariaForaneaImpl
