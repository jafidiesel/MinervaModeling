/**
 */
package modeloER.modeloER.impl;

import modeloER.modeloER.ModeloERPackage;
import modeloER.modeloER.RelacionTipoFuerte;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Relacion Tipo Fuerte</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RelacionTipoFuerteImpl extends RelacionImpl implements RelacionTipoFuerte {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RelacionTipoFuerteImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.RELACION_TIPO_FUERTE;
	}

} //RelacionTipoFuerteImpl
