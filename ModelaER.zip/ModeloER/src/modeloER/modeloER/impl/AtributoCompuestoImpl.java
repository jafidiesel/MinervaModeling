/**
 */
package modeloER.modeloER.impl;

import modeloER.modeloER.AtributoCompuesto;
import modeloER.modeloER.ModeloERPackage;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Atributo Compuesto</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AtributoCompuestoImpl extends AtributoImpl implements AtributoCompuesto {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AtributoCompuestoImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.ATRIBUTO_COMPUESTO;
	}

} //AtributoCompuestoImpl
