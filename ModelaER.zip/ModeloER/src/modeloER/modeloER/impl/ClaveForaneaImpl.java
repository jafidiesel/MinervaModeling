/**
 */
package modeloER.modeloER.impl;

import modeloER.modeloER.ClaveForanea;
import modeloER.modeloER.ModeloERPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Clave Foranea</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ClaveForaneaImpl extends AtributoImpl implements ClaveForanea {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClaveForaneaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeloERPackage.Literals.CLAVE_FORANEA;
	}

} //ClaveForaneaImpl
