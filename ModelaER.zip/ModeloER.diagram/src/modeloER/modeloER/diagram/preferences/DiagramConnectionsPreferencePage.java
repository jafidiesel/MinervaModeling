package modeloER.modeloER.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.ConnectionsPreferencePage;

/**
 * @generated
 */
public class DiagramConnectionsPreferencePage extends ConnectionsPreferencePage {

	/**
	* @generated
	*/
	public DiagramConnectionsPreferencePage() {
		setPreferenceStore(
				modeloER.modeloER.diagram.part.ModeloERDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
