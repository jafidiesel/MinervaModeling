package modeloER.modeloER.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	* @generated
	*/
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(
				modeloER.modeloER.diagram.part.ModeloERDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
