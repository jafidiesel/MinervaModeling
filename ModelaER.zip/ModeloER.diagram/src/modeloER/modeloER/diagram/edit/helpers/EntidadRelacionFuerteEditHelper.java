package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class EntidadRelacionFuerteEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
