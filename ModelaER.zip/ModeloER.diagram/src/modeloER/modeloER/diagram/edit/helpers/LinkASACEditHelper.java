package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class LinkASACEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
