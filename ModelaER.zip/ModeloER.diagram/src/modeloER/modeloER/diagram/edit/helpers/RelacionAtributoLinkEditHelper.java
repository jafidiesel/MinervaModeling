package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class RelacionAtributoLinkEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
