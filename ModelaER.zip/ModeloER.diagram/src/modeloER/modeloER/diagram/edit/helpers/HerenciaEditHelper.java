package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class HerenciaEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
