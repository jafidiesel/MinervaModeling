package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class EntidadDebilEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
