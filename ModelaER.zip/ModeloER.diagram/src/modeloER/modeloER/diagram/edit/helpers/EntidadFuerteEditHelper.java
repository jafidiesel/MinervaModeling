package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class EntidadFuerteEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
