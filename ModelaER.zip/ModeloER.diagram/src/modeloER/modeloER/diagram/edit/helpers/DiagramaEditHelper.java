package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class DiagramaEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
