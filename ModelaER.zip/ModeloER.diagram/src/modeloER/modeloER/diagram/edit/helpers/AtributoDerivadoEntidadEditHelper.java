package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class AtributoDerivadoEntidadEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
