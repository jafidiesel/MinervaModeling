package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class AtributoSimpleEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
