package modeloER.modeloER.diagram.edit.helpers;

/**
 * @generated
 */
public class ClaveForaneaEditHelper extends modeloER.modeloER.diagram.edit.helpers.ModeloERBaseEditHelper {
}
