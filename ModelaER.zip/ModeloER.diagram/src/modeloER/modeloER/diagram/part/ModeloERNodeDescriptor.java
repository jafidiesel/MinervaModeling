package modeloER.modeloER.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class ModeloERNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public ModeloERNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
